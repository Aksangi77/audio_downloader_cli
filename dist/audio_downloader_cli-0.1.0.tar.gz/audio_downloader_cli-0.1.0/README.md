# Audio Downloader CLI

A CLI tool to download audio from YouTube and other sites using yt-dlp.

## Installation

(Instructions to be added once packaging is complete)

## Usage

audio-downloader-cli <URL_OF_VIDEO>